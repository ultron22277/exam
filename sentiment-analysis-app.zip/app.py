import streamlit as st
import joblib
import numpy as np
from utils import clean_text
from gensim.models import Word2Vec
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences

tfidf = joblib.load("models/tfidf_model.pkl")
lr = joblib.load("models/lr_model.pkl")

w2v = Word2Vec.load("models/word2vec_model.model")
rf = joblib.load("models/rf_model.pkl")

lstm = load_model("models/lstm_model.h5")
tokenizer = joblib.load("models/tokenizer.pkl")

def get_avg_vector(words, model):
    vec = np.zeros(100)
    count = 0
    for word in words:
        if word in model.wv:
            vec += model.wv[word]
            count += 1
    return vec / count if count != 0 else vec

st.title("Sentiment Analysis App")

text = st.text_area("Enter Review")
model_choice = st.selectbox("Choose Model", ["TF-IDF", "Word2Vec", "LSTM"])

if st.button("Predict"):
    cleaned = clean_text(text)

    if model_choice == "TF-IDF":
        vec = tfidf.transform([cleaned])
        pred = lr.predict(vec)[0]

    elif model_choice == "Word2Vec":
        vec = get_avg_vector(cleaned.split(), w2v).reshape(1, -1)
        pred = rf.predict(vec)[0]

    else:
        seq = tokenizer.texts_to_sequences([cleaned])
        pad = pad_sequences(seq, maxlen=100)
        pred = (lstm.predict(pad) > 0.5).astype(int)[0][0]

    result = "Positive" if pred == 1 else "Negative"
    st.success(result)
