import pandas as pd
import numpy as np
import joblib
from utils import clean_text

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

from gensim.models import Word2Vec
from sklearn.ensemble import RandomForestClassifier

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

df = pd.read_csv("data/reviews.csv")
df['review'] = df['review'].apply(clean_text)

X = df['review']
y = df['sentiment']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

tfidf = TfidfVectorizer(max_features=5000)
X_train_tfidf = tfidf.fit_transform(X_train)

lr = LogisticRegression()
lr.fit(X_train_tfidf, y_train)

joblib.dump(tfidf, "models/tfidf_model.pkl")
joblib.dump(lr, "models/lr_model.pkl")

sentences = [text.split() for text in X_train]
w2v = Word2Vec(sentences, vector_size=100, window=5, min_count=1)
w2v.save("models/word2vec_model.model")

def get_avg_vector(words, model):
    vec = np.zeros(100)
    count = 0
    for word in words:
        if word in model.wv:
            vec += model.wv[word]
            count += 1
    return vec / count if count != 0 else vec

X_train_w2v = np.array([get_avg_vector(text.split(), w2v) for text in X_train])

rf = RandomForestClassifier()
rf.fit(X_train_w2v, y_train)
joblib.dump(rf, "models/rf_model.pkl")

tokenizer = Tokenizer(num_words=5000)
tokenizer.fit_on_texts(X_train)

X_seq = tokenizer.texts_to_sequences(X_train)
X_pad = pad_sequences(X_seq, maxlen=100)

model = Sequential()
model.add(Embedding(5000, 128))
model.add(LSTM(64))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(X_pad, y_train, epochs=3, batch_size=32)

model.save("models/lstm_model.h5")
joblib.dump(tokenizer, "models/tokenizer.pkl")

print("Training Complete")
